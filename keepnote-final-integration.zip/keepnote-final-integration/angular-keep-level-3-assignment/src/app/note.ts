

export class Note {
  noteId: Number;
  noteTitle: string;
  noteContent: string;
  noteStatus: string;
  noteCreationDate: string;
  noteCreatedBy: string;

  constructor() { }

}
