export class User {
    userId: string;
    userName: string;
    userPassword: string;
    userMobile: string;
    userAddedDate: string;
    firstName: string;
    lastName: string;
    userRole: string;
  
    constructor() {
      
    }
  }