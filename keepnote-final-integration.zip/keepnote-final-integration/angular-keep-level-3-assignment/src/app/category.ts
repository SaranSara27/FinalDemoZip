export class Category {
    id: string;
    categoryId: string;
    categoryName: string;
    categoryDescription: string;
    categoryCreatedBy: string;
    categoryCreationDate: string;
  
    
    constructor() {
      
    }
  }