import { Note } from "./note";

export class Noteuser {
    userId: string;
    notes: Note[];
}