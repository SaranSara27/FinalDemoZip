package com.stackroute.keepnote.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.stackroute.keepnote.exception.NoteNotFoundExeption;
import com.stackroute.keepnote.model.Notes;
import com.stackroute.keepnote.model.NoteUser;
import com.stackroute.keepnote.repository.NoteRepository;
import com.stackroute.keepnote.repository.NotesRepository;

@Service
public class NotesServiceImpl implements NotesService {
@Autowired
	private NotesRepository notesRepository;

	public NotesServiceImpl(NotesRepository noteRepository) {
		this.notesRepository = notesRepository;
	}

	/*
	 * This method should be used to save a new note.
	 */
	@Transactional
	public boolean createNote(Notes note) {
		Random random = new Random();
		int noteId = random.nextInt(99999);
		note.setNoteId(noteId);
		boolean created = false;
		Optional<NoteUser> noteUser = notesRepository.findById(note.getNoteCreatedBy());
		NoteUser userNotes = null;
		if (noteUser.isPresent()) {
			userNotes = noteUser.get();
			userNotes.getNote().add(note);
			created = notesRepository.save(userNotes) != null ? true : false;
		} else {
			userNotes = new NoteUser();
			userNotes.setUserId(note.getNoteCreatedBy());
			userNotes.setNote(Arrays.asList(note));
			created = notesRepository.insert(userNotes) != null ? true : false;
		}

		return created;
	}

	/* This method should be used to delete an existing note. */
	@Transactional
	public boolean deleteNote(String userId, int noteId) {
		boolean delete = false;
		NoteUser noteUser = null;
		try {
			noteUser = notesRepository.findById(userId).get();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
		if (noteUser != null) {
			Notes noteNew = noteUser.getNote().stream().filter(note -> note.getNoteId() == noteId).findFirst()
					.orElse(null);
			noteUser.getNote().remove(noteNew);
			notesRepository.save(noteUser);
			delete = true;
		}
		return delete;
	}

	/* This method should be used to delete all notes with specific userId. */
	@Transactional
	public boolean deleteAllNotes(String userId) {
		boolean delete = false;
		NoteUser noteUser = notesRepository.findById(userId).get();
		if (noteUser != null) {
			notesRepository.delete(noteUser);
			delete = true;
		}
		return delete;
	}

	/*
	 * This method should be used to update a existing note.
	 */
	@Transactional
	public Notes updateNote(Notes note, int id, String userId) throws NoteNotFoundExeption {
		NoteUser noteUser = null;
		try {
			noteUser = notesRepository.findById(userId).get();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
		if (noteUser != null) {
			List<Notes> notes = noteUser.getNote();
			Notes fetchedNote = notes.stream().filter(notefilter -> notefilter.getNoteId() == id).findFirst()
					.orElse(null);
			if (note != null) {
				noteUser.getNote().remove(fetchedNote);
				noteUser.getNote().add(note);
				notesRepository.save(noteUser);
			}
		} else {
			throw new NoteNotFoundExeption("Not found");
		}

		return note;
	}

	/*
	 * This method should be used to get a note by noteId created by specific user
	 */
	public Notes getNoteByNoteId(String userId, int noteId) throws NoteNotFoundExeption {
		Notes note = null;
		List<Notes> noteList = new ArrayList<>();
		try {
			NoteUser noteUser = notesRepository.findById(userId).get();
			if (noteUser != null) {
				noteList = noteUser.getNote();
				note = noteList.stream().filter(noteFilter -> noteFilter.getNoteId() == noteId).findFirst()
						.orElse(null);
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
		if (note == null) {
			throw new NoteNotFoundExeption("Not found");
		}
		return note;
	}

	/*
	 * This method should be used to get all notes with specific userId.
	 */
	public List<Notes> getAllNoteByUserId(String userId) {
		List<Notes> noteList = new ArrayList<>();
		Optional<NoteUser> noteUser = notesRepository.findById(userId);
		if (noteUser != null && noteUser.isPresent()) {
			noteList = noteUser.get().getNote();
		}

		return noteList;
	}

	@Override
	public NoteUser updateUserNote(NoteUser noteUser, String userId) {
		// TODO Auto-generated method stub
		return notesRepository.save(noteUser);
	}

}
