package com.stackroute.keepnote.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class NoteUser {

	@Id
	private String userId;
	private List<Note> notes;
	private List<Notes> note;
	public NoteUser() {
	}
	public NoteUser(String userId, List<Note> notes, List<Notes> note) {
		super();
		this.userId = userId;
		this.notes = notes;
		this.note = note;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<Note> getNotes() {
		return notes;
	}
	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}
	public List<Notes> getNote() {
		return note;
	}
	public void setNote(List<Notes> note) {
		this.note = note;
	}

	
}
