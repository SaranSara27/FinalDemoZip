package com.stackroute.keepnote.service;

import com.stackroute.keepnote.exception.NoteNotFoundExeption;
import com.stackroute.keepnote.model.Notes;
import com.stackroute.keepnote.model.NoteUser;

import java.util.List;


public interface NotesService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */


    boolean createNote(Notes note);

    boolean deleteNote(String userId, int noteId);

    boolean deleteAllNotes(String userId) throws NoteNotFoundExeption;

    Notes updateNote(Notes note, int id, String userId) throws NoteNotFoundExeption;

    Notes getNoteByNoteId(String userId,int noteId) throws NoteNotFoundExeption;

    List<Notes> getAllNoteByUserId(String userId);
    
    NoteUser updateUserNote(NoteUser noteUser, String userId);


}
